<?php
		echo"<script>";
		echo"alert('Logout from account')";
		echo"</script>";
		include("homepagelogin.html");
?>