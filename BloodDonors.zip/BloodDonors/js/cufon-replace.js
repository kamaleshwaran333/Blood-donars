Cufon.replace('h2, h3, .title-1', { fontFamily: 'Vegur', textShadow: "1px 1px rgba(0, 0, 0, 0.1)", hover:true });
Cufon.replace('.menu a', { fontFamily: 'Ropa Sans', hover:true });
